package aula08;

public interface Vegetariano {
    
}
