package aula08;

public class Legume extends Vegetal {

    public Legume(String nome, double proteinas, double calorias, double peso) {
        super(proteinas, calorias, peso, nome);
    }
    
}
