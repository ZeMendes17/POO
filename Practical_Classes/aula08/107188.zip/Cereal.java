package aula08;

public class Cereal extends Vegetal {

    public Cereal(String nome, double proteinas, double calorias, double peso) {
        super(proteinas, calorias, peso, nome);
    }


    
}
